<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <title>Intranet Mas</title>
</head>
<body>
    <?php 
    require '../parciales/header.php'
    ?>
    <h1>Bienvenidos</h1>

    <a href="login.php">Login</a>
</body>
</html>