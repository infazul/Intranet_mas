-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2019 a las 19:40:02
-- Versión del servidor: 10.3.15-MariaDB
-- Versión de PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `intranet_mas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `idalumno` int(11) NOT NULL,
  `curso` varchar(20) DEFAULT NULL,
  `fechaNac` date NOT NULL,
  `usuarios_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `apoderado`
--

CREATE TABLE `apoderado` (
  `idapoderado` int(11) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `usuarios_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE `asignatura` (
  `idasignatura` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `gradoAcademico_idgradoAcademico` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarioforo`
--

CREATE TABLE `comentarioforo` (
  `idcomentarioForo` int(11) NOT NULL,
  `mensaje` longtext NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `temaForo_idtemaForo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuestionario`
--

CREATE TABLE `cuestionario` (
  `idcuestionario` int(11) NOT NULL,
  `numeroPreguntas` int(11) NOT NULL,
  `asignatura_idasignatura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gradoacademico`
--

CREATE TABLE `gradoacademico` (
  `idgradoAcademico` int(11) NOT NULL,
  `grado` varchar(45) NOT NULL,
  `profesor_idprofesor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `material`
--

CREATE TABLE `material` (
  `idmaterial` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `asignatura_idasignatura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `mensaje` varchar(999) NOT NULL,
  `remitente` varchar(180) NOT NULL,
  `destinatario` varchar(180) NOT NULL,
  `fecha` varchar(180) NOT NULL,
  `leido` varchar(10) DEFAULT NULL,
  `asunto` varchar(180) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id`, `mensaje`, `remitente`, `destinatario`, `fecha`, `leido`, `asunto`) VALUES
(1, 'asdadsasdasd', 'Hola2@123.cl', 'hola@123.cl', '1/07/2019, 9:54 pm', NULL, 'Hola'),
(2, 'qswdfghjk', 'Hola@123.cl', 'hola2@123.cl', '1/07/2019, 10:15 pm', NULL, 'hola'),
(3, 'asdfgfds', 'Hola@123.cl', 'hola@123.cl', '1/07/2019, 10:52 pm', NULL, '77');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota`
--

CREATE TABLE `nota` (
  `idnota` int(11) NOT NULL,
  `nota` float NOT NULL,
  `asignatura_idasignatura` int(11) NOT NULL,
  `cuestionario_idcuestionario` int(11) NOT NULL,
  `alumno_idalumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE `pregunta` (
  `idpregunta` int(11) NOT NULL,
  `pregunta` varchar(100) NOT NULL,
  `respuesta1` varchar(70) NOT NULL,
  `respuesta2` varchar(70) NOT NULL,
  `respuesta3` varchar(70) NOT NULL,
  `respuesta4` varchar(70) NOT NULL,
  `respuestaCorrecta` int(11) NOT NULL,
  `respuestaAlumno` int(11) DEFAULT NULL,
  `cuestionario_idcuestionario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `idprofesor` int(11) NOT NULL,
  `area` varchar(45) DEFAULT NULL,
  `telefono` varchar(12) DEFAULT NULL,
  `usuarios_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temaforo`
--

CREATE TABLE `temaforo` (
  `idtemaForo` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `contenido` longtext NOT NULL,
  `usuarios_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `rut` varchar(10) NOT NULL,
  `password` varchar(180) NOT NULL,
  `perfil` int(11) NOT NULL,
  `primer_nombre` varchar(20) NOT NULL,
  `segundo_nombre` varchar(20) DEFAULT NULL,
  `primer_apellido` varchar(20) NOT NULL,
  `segundo_apellido` varchar(20) DEFAULT NULL,
  `correo` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `rut`, `password`, `perfil`, `primer_nombre`, `segundo_nombre`, `primer_apellido`, `segundo_apellido`, `correo`) VALUES
(1, '19646338-0', '123456', 0, 'Fabian', 'Esteban', 'Rosado', 'Jara', ''),
(6, '18638466-0', '$2y$10$YN3.ioEA6RBaJEHaKQNEfOjqyLi.Aic5KMz7U5fvuzHD1FfdhMjc.', 0, 'Paul', 'Elias', 'OrmeÃ±o', 'MuÃ±oz', 'Hola@123.cl'),
(8, '1234-2', '$2y$10$fXgcQm0b7O8c1K7czFsxBu14hujetOe42i7zsFnFMzY7MtgaZw.3e', 3, 'Miguel', '', 'Lopez', 'Lopez', 'Hola2@123.cl'),
(9, '1234-1', '$2y$10$vdCeVbDfEGM5Oi.EJ03d7urr8R2SAJ.lbpzd/pat/.ujQ8vOJjmVW', 3, 'Alex', '', 'Sanchez', 'MuÃ±oz', 'Hola@123.cl'),
(10, '9876-0', '$2y$10$25UlO/ncSWxmQym5sbDZ0.y3tiLA7RjLwTsOAuY3Xox.wdLgwemzm', 1, 'Ignacio', 'Alejandro', 'Palma', 'Carrasco', 'hola0@123.cl'),
(11, '5678-9', '$2y$10$c8BVN3EJkyFcZA7NWfTcD.5E5QBWMgVJBJRKSdVghnf4R.ysmLjDO', 2, 'Juana', 'Ignacia', 'Molina', 'Perez', 'apo@123.cl');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`idalumno`,`usuarios_id`),
  ADD KEY `fk_alumno_usuarios1_idx` (`usuarios_id`);

--
-- Indices de la tabla `apoderado`
--
ALTER TABLE `apoderado`
  ADD PRIMARY KEY (`idapoderado`,`usuarios_id`),
  ADD KEY `fk_apoderado_usuarios_idx` (`usuarios_id`);

--
-- Indices de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD PRIMARY KEY (`idasignatura`,`gradoAcademico_idgradoAcademico`),
  ADD KEY `fk_asignatura_gradoAcademico1_idx` (`gradoAcademico_idgradoAcademico`);

--
-- Indices de la tabla `comentarioforo`
--
ALTER TABLE `comentarioforo`
  ADD PRIMARY KEY (`idcomentarioForo`,`usuarios_id`,`temaForo_idtemaForo`),
  ADD KEY `fk_comentarioForo_usuarios1_idx` (`usuarios_id`),
  ADD KEY `fk_comentarioForo_temaForo1_idx` (`temaForo_idtemaForo`);

--
-- Indices de la tabla `cuestionario`
--
ALTER TABLE `cuestionario`
  ADD PRIMARY KEY (`idcuestionario`,`asignatura_idasignatura`),
  ADD KEY `fk_cuestionario_asignatura1_idx` (`asignatura_idasignatura`);

--
-- Indices de la tabla `gradoacademico`
--
ALTER TABLE `gradoacademico`
  ADD PRIMARY KEY (`idgradoAcademico`,`profesor_idprofesor`),
  ADD KEY `fk_gradoAcademico_profesor1_idx` (`profesor_idprofesor`);

--
-- Indices de la tabla `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`idmaterial`,`asignatura_idasignatura`),
  ADD KEY `fk_material_asignatura1_idx` (`asignatura_idasignatura`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`idnota`,`asignatura_idasignatura`,`cuestionario_idcuestionario`,`alumno_idalumno`),
  ADD KEY `fk_nota_asignatura1_idx` (`asignatura_idasignatura`),
  ADD KEY `fk_nota_cuestionario1_idx` (`cuestionario_idcuestionario`),
  ADD KEY `fk_nota_alumno1_idx` (`alumno_idalumno`);

--
-- Indices de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD PRIMARY KEY (`idpregunta`,`cuestionario_idcuestionario`),
  ADD KEY `fk_pregunta_cuestionario1_idx` (`cuestionario_idcuestionario`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`idprofesor`,`usuarios_id`),
  ADD KEY `fk_profesor_usuarios1_idx` (`usuarios_id`);

--
-- Indices de la tabla `temaforo`
--
ALTER TABLE `temaforo`
  ADD PRIMARY KEY (`idtemaForo`,`usuarios_id`),
  ADD KEY `fk_temaForo_usuarios1_idx` (`usuarios_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
  MODIFY `idalumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `apoderado`
--
ALTER TABLE `apoderado`
  MODIFY `idapoderado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  MODIFY `idasignatura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comentarioforo`
--
ALTER TABLE `comentarioforo`
  MODIFY `idcomentarioForo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cuestionario`
--
ALTER TABLE `cuestionario`
  MODIFY `idcuestionario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `gradoacademico`
--
ALTER TABLE `gradoacademico`
  MODIFY `idgradoAcademico` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `material`
--
ALTER TABLE `material`
  MODIFY `idmaterial` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `nota`
--
ALTER TABLE `nota`
  MODIFY `idnota` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  MODIFY `idpregunta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `idprofesor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `temaforo`
--
ALTER TABLE `temaforo`
  MODIFY `idtemaForo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD CONSTRAINT `fk_alumno_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `apoderado`
--
ALTER TABLE `apoderado`
  ADD CONSTRAINT `fk_apoderado_usuarios` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD CONSTRAINT `fk_asignatura_gradoAcademico1` FOREIGN KEY (`gradoAcademico_idgradoAcademico`) REFERENCES `gradoacademico` (`idgradoAcademico`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comentarioforo`
--
ALTER TABLE `comentarioforo`
  ADD CONSTRAINT `fk_comentarioForo_temaForo1` FOREIGN KEY (`temaForo_idtemaForo`) REFERENCES `temaforo` (`idtemaForo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_comentarioForo_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cuestionario`
--
ALTER TABLE `cuestionario`
  ADD CONSTRAINT `fk_cuestionario_asignatura1` FOREIGN KEY (`asignatura_idasignatura`) REFERENCES `asignatura` (`idasignatura`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `gradoacademico`
--
ALTER TABLE `gradoacademico`
  ADD CONSTRAINT `fk_gradoAcademico_profesor1` FOREIGN KEY (`profesor_idprofesor`) REFERENCES `profesor` (`idprofesor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `fk_material_asignatura1` FOREIGN KEY (`asignatura_idasignatura`) REFERENCES `asignatura` (`idasignatura`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `nota`
--
ALTER TABLE `nota`
  ADD CONSTRAINT `fk_nota_alumno1` FOREIGN KEY (`alumno_idalumno`) REFERENCES `alumno` (`idalumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_nota_asignatura1` FOREIGN KEY (`asignatura_idasignatura`) REFERENCES `asignatura` (`idasignatura`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_nota_cuestionario1` FOREIGN KEY (`cuestionario_idcuestionario`) REFERENCES `cuestionario` (`idcuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD CONSTRAINT `fk_pregunta_cuestionario1` FOREIGN KEY (`cuestionario_idcuestionario`) REFERENCES `cuestionario` (`idcuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD CONSTRAINT `fk_profesor_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `temaforo`
--
ALTER TABLE `temaforo`
  ADD CONSTRAINT `fk_temaForo_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
